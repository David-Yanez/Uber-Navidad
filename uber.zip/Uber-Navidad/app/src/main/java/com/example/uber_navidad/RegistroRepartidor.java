package com.example.uber_navidad;

public class RegistroRepartidor {
}
