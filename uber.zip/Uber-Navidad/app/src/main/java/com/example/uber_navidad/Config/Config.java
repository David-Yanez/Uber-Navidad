package com.example.uber_navidad.Config;

public class Config {
    public static final String PAYPAL_CLIENT_ID = "AasOGSQXCzRzlpyd1APreDFyDaRiCS0i5nQM5XQAQPSbBvpmQEOBW2UAeZJSfZvSP-aIDMBXkOMkYLQD";
}
