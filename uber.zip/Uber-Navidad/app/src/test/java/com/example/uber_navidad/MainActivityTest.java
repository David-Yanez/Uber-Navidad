package com.example.uber_navidad;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class MainActivityTest {

    @Before
    public void setUp() throws Exception {
        MainActivityc cedula = new MainActivityTest()
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void validaCedula() {
        assertTrue(cadula.isLeap(1724523384));

    }
}